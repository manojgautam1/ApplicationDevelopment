﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FundTracker.Base
{
    public enum Currency
    {
        NPR=1,
        INR=2,
        USD=3,
    }
}
