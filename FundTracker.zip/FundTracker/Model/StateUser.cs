﻿namespace FundTracker.Model
{
    public class StateUser
    {
        public User UserStatus { get; set; }    
    }
}
