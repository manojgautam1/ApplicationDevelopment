using FundTracker.Model;

namespace FundTracker.Components.Layout
{
    public partial class MainLayout
    {
        private StateUser _Status = new();
    }
}